<!DOCTYPE html>
<html>
<head>
    <title>Zizmart</title>
</head>
<body>
    <h1>Welcome to Zizmart!</h1>
    <p>Your online shopping platform.</p>
</body>
</html>
